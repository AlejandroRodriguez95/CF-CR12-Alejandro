<?php get_header(); ?>




<!-- Navbar ends -->

<div class="container">
    <h1 class="pt-3 text-center mb-0"><i>Travel with style</i></h1>
    <h5 class="text-center pb-3"><i><b>Lorem ipsum dolor sit amet, consectetur adipiscing elit</i></b></h5>
</div>
<?php wp_footer(); ?>
<?php get_footer(); ?>