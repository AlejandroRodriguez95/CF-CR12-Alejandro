<?php get_header();
    $first = 0;
    $one = 1;
    ?>
<div class="container">
    <h1 class="pt-3 text-center mb-0 title"><i>Travel with style</i></h1>
    <br>
    <h5 class="text-center pb-3"><i><b>Lorem ipsum dolor sit amet, consectetur adipiscing elit</i></b></h5>
</div>
<div class=container-flex>
    <div class="row">
        <div class="col-lg-10">
            <div class='row'>
                <div class="col-3">
                    <?php
                        if(is_active_sidebar('sidebar')):
                        dynamic_sidebar('sidebar');
                        endif;  
                    ?>
                </div>
                <?php if(have_posts()) : ?>
                <!--  If there are posts available  -->

                <?php while(have_posts()) : the_post(); ?>
                <!-- if there are posts, iterate the posts in the loop-->

                <?php if($first == 0) :?>
                <div class="card col-lg-3 p-2 mb-3 ">
                    <div class='text-center mx-auto'>
                        <?php if(has_post_thumbnail()) : ?><?php the_post_thumbnail('full'); ?><?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h4 class="text-center"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
                        <p class="text-center"><i><?php the_content(); ?></i></p>
                        <hr>
                        <p><i><?php the_time('F j, Y g:i a'); ?></i></p>
                        <!--retrieves date blog entry was created-->
                        <hr>
                        <p><b>Posted by:</b> <?php the_author(); $first = 1; ?></p>
                    </div>
                </div>
                <?php else: ?>
                <div class="card col-lg-3 p-2 mb-3  <?php if(($one%3)== 0) : ?>offset-lg-3<?php endif;?>">
                    <div class='text-center mx-auto'>
                        <?php if(has_post_thumbnail()) : ?><?php the_post_thumbnail('full');$one++;?><?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h4 class="text-center"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
                        <p class="text-center"><i><?php the_content(); ?></i></p>
                        <hr>
                        <p><i><?php the_time('F j, Y g:i a'); ?></i></p>
                        <!--retrieves date blog entry was created-->
                        <hr>
                        <p><b>Posted by:</b> <?php the_author(); $first = 1; ?></p>
                    </div>
                </div>
                        <?php endif; ?>
                <?php endwhile; ?>
                <!--end the while loop-->

                <?php else :?>
                <!-- if no posts are found then: -->

                <p>No posts found</p> <!-- no posts found displayed -->
                <?php endif; ?>
                <!-- end if -->
            </div>
        </div>
    </div>

</div>
<?php wp_footer(); ?>
<?php get_footer(); ?>