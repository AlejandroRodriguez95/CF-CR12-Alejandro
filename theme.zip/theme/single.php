<?php get_header(); ?>
<div class="container">

       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop
-->
        <div class="col-8">
            <h4 class="text-center"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
            <p class="text-center"><i><?php the_content(); ?></i></p>
            <p><i><?php the_time('F j, Y g:i a'); ?></i></p><!--retrieves date blog entry was created-->
            <p>Posted by: <?php the_author(); ?></p><!--retrieves author of blog entry-->
            <h5><a href="<?php echo home_url(); ?>">Go back to home!</a></h5>
        </div>
        <?php comment_form(); ?>
       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>
       <?php endif; ?> <!-- end if -->
   </div>
   <?php get_footer(); ?>