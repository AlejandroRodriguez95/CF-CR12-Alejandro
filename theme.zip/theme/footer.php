<?php wp_footer(); ?>

<div class='footer-size bg-dark'>
    <div class="row p-5">
        <div class="text-center text-light col-6">Footer item 1</div>
        <div class="text-center text-light col-6">Footer item 2</div>
    </div>
</div>
</body>
</html>