<?php get_header(); ?>
    <div class="container">

        <h1 class="pt-3 text-center mb-0"><i>Website Title</i></h1>
        <h5 class="text-center pb-3"><i><b>slogan</i></b></h5> 

            <div class="row">

                <?php if(have_posts()) : ?> <!--  If there are posts available  -->

                <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop-->

                <div class="col-lg-4 col-sm-12 col-md-6">
                    <?php if(has_post_thumbnail()) : ?><?php the_post_thumbnail('full'); ?><?php endif; ?>
                    <h4 class="text-center"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
                    <p class="text-center"><i><?php the_content(); ?></i></p>
                    <p><i><?php the_time('F j, Y g:i a'); ?></i></p><!--retrieves date blog entry was created-->
                    <p>Posted by: <?php the_author(); ?></p><!--retrieves author of blog entry-->
                </div>

                <?php endwhile; ?><!--end the while loop-->

                <?php else :?> <!-- if no posts are found then: -->

                <p>No posts found</p>  <!-- no posts found displayed -->
                <?php endif; ?> <!-- end if -->
            </div>

    </div>
    <?php get_footer(); ?>