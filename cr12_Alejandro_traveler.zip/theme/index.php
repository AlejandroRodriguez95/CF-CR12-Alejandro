<?php get_header(); ?>



<?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?>
    <!-- Navbar ends -->

    <div class="container">

        <h1 class="pt-3 text-center mb-0"><i>Website Title</i></h1>
        <h5 class="text-center pb-3"><i><b>slogan</i></b></h5> 

    </div>
<?php wp_footer(); ?>
<?php get_footer(); ?>